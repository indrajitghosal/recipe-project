document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ JavaScript Loaded Successfully!");

    /** 🎬 LANDING PAGE TRANSITION **/
    const getStartedBtn = document.getElementById("get-started-btn");
    const landingPage = document.getElementById("landing-page");
    const mainContent = document.getElementById("main-content");

    if (mainContent) {
        mainContent.style.display = "none";
    }

    if (getStartedBtn) {
        getStartedBtn.addEventListener("click", function () {
            landingPage.style.display = "none";
            mainContent.style.display = "block";
            localStorage.setItem("visited", "true");
        });
    }

    if (localStorage.getItem("visited") === "true") {
        landingPage.style.display = "none";
        mainContent.style.display = "block";
    }

    /** 🎨 DARK MODE TOGGLE **/
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    if (darkModeToggle) {
        darkModeToggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode");
            localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light");
        });

        if (localStorage.getItem("theme") === "dark") {
            document.body.classList.add("dark-mode");
        }
    }

    /** 🔍 SEARCH FUNCTIONALITY **/
    const searchInput = document.getElementById("search-bar");
    const searchButton = document.getElementById("search-button");
    const searchSuggestions = document.getElementById("search-suggestions");

    if (searchInput && searchButton) {
        searchButton.addEventListener("click", function (event) {
            event.preventDefault();
            performSearch(searchInput.value.trim());
        });

        searchInput.addEventListener("input", function () {
            const query = searchInput.value.trim().toLowerCase();
            searchSuggestions.innerHTML = "";

            if (query.length > 0) {
                fetch(`/search_suggestions?query=${query}`)
                    .then(response => response.json())
                    .then(data => {
                        searchSuggestions.innerHTML = "";
                        searchSuggestions.style.display = data.length > 0 ? "block" : "none";
                        data.forEach(item => {
                            const li = document.createElement("li");
                            li.textContent = item;
                            li.classList.add("suggestion-item");
                            li.onclick = () => {
                                searchInput.value = item;
                                searchSuggestions.innerHTML = "";
                                searchSuggestions.style.display = "none";
                                performSearch(item);
                            };
                            searchSuggestions.appendChild(li);
                        });
                    })
                    .catch(error => console.error("🚨 Search Fetch Error:", error));
            }
        });
    }

    function performSearch(query) {
        if (query.length > 0) {
            window.location.href = `/search?query=${encodeURIComponent(query)}`;
        }
    }

    /** 📍 CATEGORY NAVIGATION **/
    function navigateTo(category) {
        if (!category) return;
        window.location.href = `/region/${encodeURIComponent(category)}`;
    }

    document.querySelectorAll(".category-box").forEach(box => {
        box.addEventListener("click", function () {
            let category = this.getAttribute("data-category") || this.textContent.trim();
            navigateTo(category);
        });
    });

    /** ❤️ FAVORITES FEATURE **/
    let favorites = JSON.parse(localStorage.getItem("favorites")) || [];
    const favoritesList = document.getElementById("favorite-recipes");

    function updateFavorites() {
        if (favoritesList) {
            favoritesList.innerHTML = "";
            if (favorites.length === 0) {
                favoritesList.innerHTML = "<li>No favorite recipes yet!</li>";
                return;
            }

            favorites.forEach(item => {
                const li = document.createElement("li");
                li.textContent = item;
                li.classList.add("favorite-item");

                const removeBtn = document.createElement("button");
                removeBtn.textContent = "❌";
                removeBtn.classList.add("remove-favorite");
                removeBtn.onclick = () => {
                    favorites = favorites.filter(fav => fav !== item);
                    localStorage.setItem("favorites", JSON.stringify(favorites));
                    updateFavorites();
                };

                li.appendChild(removeBtn);
                favoritesList.appendChild(li);
            });
        }
    }

    document.querySelectorAll(".recipe-item").forEach(item => {
        item.addEventListener("click", function () {
            let recipeName = this.textContent.trim();
            if (!favorites.includes(recipeName)) {
                favorites.push(recipeName);
                localStorage.setItem("favorites", JSON.stringify(favorites));
                updateFavorites();
            }
            window.location.href = this.getAttribute("data-url") || "#";
        });
    });

    updateFavorites();
});
